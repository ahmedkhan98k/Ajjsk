const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// تحميل تيك توك
async function getTikTok(url) {
    try {
        const response = await axios.get(`https://tikwm.com/api/?url=${encodeURIComponent(url)}&hd=1`);
        if (response.data.code === 0 && response.data.data) {
            const videoUrl = response.data.data.hdplay || response.data.data.play;
            return { success: true, url: 'https://tikwm.com' + videoUrl, title: response.data.data.title };
        }
        return { success: false, error: 'فشل تحميل تيك توك' };
    } catch(e) {
        return { success: false, error: e.message };
    }
}

// تحميل يوتيوب
async function getYouTube(url) {
    try {
        const match = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|v\/|shorts\/))([^?&]+)/);
        if (!match) return { success: false, error: 'رابط يوتيوب غير صالح' };
        
        const response = await axios.get(`https://pipedapi.kavin.rocks/streams/${match[1]}`);
        const video = response.data.videoStreams?.find(v => v.quality === '720p') || response.data.videoStreams?.[0];
        if (video) return { success: true, url: video.url, title: response.data.title };
        return { success: false, error: 'فشل تحميل يوتيوب' };
    } catch(e) {
        return { success: false, error: e.message };
    }
}

// تحميل فيسبوك
async function getFacebook(url) {
    try {
        const response = await axios.post('https://getmyfb.com/api/video', 
            new URLSearchParams({ url: url }),
            { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
        );
        if (response.data.video_url) {
            return { success: true, url: response.data.video_url, title: 'Facebook Video' };
        }
        return { success: false, error: 'فشل تحميل فيسبوك' };
    } catch(e) {
        return { success: false, error: e.message };
    }
}

// تحميل بنترست
async function getPinterest(url) {
    try {
        const response = await axios.get(`https://pinterestdownloader.com/api/download?url=${encodeURIComponent(url)}`);
        if (response.data.videoUrl) {
            return { success: true, url: response.data.videoUrl, title: 'Pinterest Video' };
        }
        return { success: false, error: 'فشل تحميل بنترست' };
    } catch(e) {
        return { success: false, error: e.message };
    }
}

// تحميل تويتر
async function getTwitter(url) {
    try {
        const response = await axios.get(`https://twitsave.com/info?url=${encodeURIComponent(url)}`);
        const match = response.data.match(/https:\/\/video\.twitsave\.com\/[^"']+\.mp4/);
        if (match) {
            return { success: true, url: match[0], title: 'Twitter Video' };
        }
        return { success: false, error: 'فشل تحميل تويتر' };
    } catch(e) {
        return { success: false, error: e.message };
    }
}

// API الرئيسي
app.get('/api/download', async (req, res) => {
    const url = req.query.url;
    if (!url) {
        return res.json({ success: false, error: 'الرجاء إرسال رابط' });
    }
    
    const domain = url.toLowerCase();
    let result;
    
    if (domain.includes('tiktok.com')) result = await getTikTok(url);
    else if (domain.includes('youtube.com') || domain.includes('youtu.be')) result = await getYouTube(url);
    else if (domain.includes('facebook.com')) result = await getFacebook(url);
    else if (domain.includes('pinterest.com') || domain.includes('pin.it')) result = await getPinterest(url);
    else if (domain.includes('twitter.com') || domain.includes('x.com')) result = await getTwitter(url);
    else result = { success: false, error: 'المنصة غير مدعومة حالياً' };
    
    res.json(result);
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});